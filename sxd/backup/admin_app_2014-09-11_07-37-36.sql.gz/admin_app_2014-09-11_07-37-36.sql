#SXD20|20011|50616|50509|2014.09.11 07:37:36|admin_app|0|6|12|
#TA account`7`16384|account_online`1`16384|calendar`0`16384|job`0`16384|job_detail`0`16384|unit`4`16384
#VI account_info|job_info
#EOH

#	TC`account`utf8_general_ci	;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `avatar` varchar(50) DEFAULT 'avatar-default.jpg',
  `unit_id` int(11) NOT NULL,
  `status` int(5) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `unit_id` (`unit_id`),
  CONSTRAINT `fk_unit_id1` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8	;
#	TD`account`utf8_general_ci	;
INSERT INTO `account` VALUES 
(1,'admin@gmail.com','e10adc3949ba59abbe56e057f20f883e','Phạm Tất Đạt','avatar-1.jpg',1,3),
(2,'manhnb@gmail.com','25f9e794323b453885f5181f1b624d0b','Bùi Tiến Mạnh','avatar-2.jpg',2,1),
(3,'ngant@gmail.com','e10adc3949ba59abbe56e057f20f883e','Nguyễn Thị Ngân','avatar-3.jpg',1,1),
(4,'thaont@gmail.com','e10adc3949ba59abbe56e057f20f883e','Nguyễn Thị Thảo','avatar-4.jpg',1,1),
(5,'thongbm@gmail.com','e10adc3949ba59abbe56e057f20f883e','Bùi Minh Thông','avatar-5.jpg',3,1),
(6,'kunny171@gmail.com','e10adc3949ba59abbe56e057f20f883e','Phạm Tất Đạt','avatar-6.jpg',1,1),
(7,'sennt@gmail.com','e10adc3949ba59abbe56e057f20f883e','Nguyễn Thị Sen','avatar-7.jpg',2,2)	;
#	TC`account_online`utf8_general_ci	;
CREATE TABLE `account_online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `time_login` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_id1` (`account_id`),
  KEY `unit_id1` (`unit_id`),
  CONSTRAINT `fk_unit_online` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_online` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`account_online`utf8_general_ci	;
INSERT INTO `account_online` VALUES 
(10,1,1,'2014-09-10 14:10:09')	;
#	TC`calendar`utf8_general_ci	;
CREATE TABLE `calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cal_content` int(11) NOT NULL,
  `account_manager` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `cal_join` text NOT NULL,
  `cal_address` text NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `unit_id2` (`unit_id`),
  KEY `account_id` (`account_manager`),
  CONSTRAINT `fk_unit_id3` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_account_id3` FOREIGN KEY (`account_manager`) REFERENCES `account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TC`job`utf8_general_ci	;
CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_id` int(11) NOT NULL,
  `job_name` text NOT NULL,
  `job_des` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `unit_id1` (`unit_id`),
  CONSTRAINT `fk_unit_id2` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`job_detail`utf8_general_ci	;
CREATE TABLE `job_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `jobd_name` text NOT NULL,
  `jobd_des` text NOT NULL,
  `jobd_timestart` datetime NOT NULL,
  `jobd_timeend` datetime NOT NULL,
  `jobd_note` text NOT NULL,
  `account_manager` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `job_id` (`job_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `fk_account_id` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_job_id` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`unit`utf8_general_ci	;
CREATE TABLE `unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` text NOT NULL,
  `unit_des` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`unit`utf8_general_ci	;
INSERT INTO `unit` VALUES 
(1,'Cục thuế','Cục thuế'),
(2,'Cục Xuất Nhập Khẩu','Cục Xuất Nhập Khẩu'),
(3,'Cục Hải Quan','Cục Hải Quan'),
(4,'Cục Tổng Ngành','Cục Tổng Ngành')	;
#	VI`account_info`utf8_general_ci	;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `account_info` AS select `account`.`id` AS `id`,`account`.`email` AS `email`,`account`.`password` AS `password`,`account`.`fullname` AS `fullname`,`account`.`avatar` AS `avatar`,`account`.`unit_id` AS `unit_id`,`account`.`status` AS `status`,`unit`.`unit_name` AS `unit_name`,`unit`.`unit_des` AS `unit_des` from (`account` join `unit`) where (`account`.`unit_id` = `unit`.`id`)	;
#	VI`job_info`utf8_general_ci	;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `job_info` AS select `job`.`id` AS `id`,`job`.`unit_id` AS `unit_id`,`job`.`job_name` AS `job_name`,`job`.`job_des` AS `job_des`,`unit`.`unit_name` AS `unit_name` from (`job` join `unit`) where (`job`.`unit_id` = `unit`.`id`)	;
